import Image from "@/components/next/Image";
import Link from "@/components/next/Link";
import { useEffect, useRef, useState } from "react";
const navLinks = [
    { label: "Home", href: "/" },
    { label: "About Us", href: "/about" },
    { label: "Our Causes", href: "#" },
    { label: "Contact", href: "#" },
    { label: "Help", href: "#" },
    { label: "Blogs", href: "/blog" },
];
const slides = [
    {
        src: "/images/hero/slide-1.jpg",
        alt: "Volunteers distributing food in the community",
    },
    {
        src: "/images/hero/slide-2.jpg",
        alt: "Students learning together in a classroom",
    },
    {
        src: "/images/hero/slide-3.jpg",
        alt: "Volunteers preparing fresh produce for distribution",
    },
];
const FADE_MS = 1000;
const INTERVAL_MS = 6500;
export function Hero() {
    const [active, setActive] = useState(0);
    const [ready, setReady] = useState(false);
    const [menuOpen, setMenuOpen] = useState(false);
    const [reduceMotion, setReduceMotion] = useState(false);
    const paused = useRef(false);
    const menuOpenRef = useRef(false);
    useEffect(() => {
        menuOpenRef.current = menuOpen;
        if (menuOpen)
            paused.current = true;
        else
            paused.current = false;
    }, [menuOpen]);
    useEffect(() => {
        const media = window.matchMedia("(prefers-reduced-motion: reduce)");
        setReduceMotion(media.matches);
        const timer = window.setTimeout(() => setReady(true), 500);
        if (media.matches) {
            return () => window.clearTimeout(timer);
        }
        const id = window.setInterval(() => {
            if (paused.current || document.hidden || menuOpenRef.current)
                return;
            setActive((current) => (current + 1) % slides.length);
        }, INTERVAL_MS);
        return () => {
            window.clearTimeout(timer);
            window.clearInterval(id);
        };
    }, []);
    function showSlide(index) {
        setReady(true);
        setActive(index);
    }
    const visibleSlides = ready ? slides : slides.slice(0, 1);
    return (<section className="bg-white ">
      <div className="relative mx-auto h-[clamp(420px,58vw,600px)] overflow-hidden " onMouseEnter={() => {
            paused.current = true;
        }} onMouseLeave={() => {  
            paused.current = menuOpenRef.current;
        }}>
        <div className="absolute inset-0 bg-[#243028]" style={{ position: "absolute" }} aria-hidden>
          {visibleSlides.map((slide, index) => (<Image key={slide.src} src={slide.src} alt={index === active ? slide.alt : ""} fill priority={index === 0} sizes="(max-width: 768px) 100vw, 1440px" className={`object-cover object-center ${reduceMotion ? "" : "transition-opacity ease-in-out"} ${index === active ? "opacity-100" : "opacity-0"}`} style={reduceMotion ? undefined : { transitionDuration: `${FADE_MS}ms` }}/>))}
        </div>

        <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(180deg,rgba(0,0,0,0.42)_0%,rgba(0,0,0,0.22)_48%,rgba(0,0,0,0.42)_100%)]" aria-hidden/>

        <div className="relative mx-auto max-w-[1400px] z-10 flex h-full flex-col px-3.5 py-3 sm:px-6 sm:py-5 lg:px-8 lg:py-6">
          <header className="grid grid-cols-[1fr_auto_1fr] items-center gap-4">
            <Link href="/" className="relative z-20 justify-self-start">
              <Image src="/images/logo.png" alt="Nalvalam Foundation" width={1536} height={1024} priority className="!h-12 !w-auto mix-blend-lighten sm:!h-14 lg:!h-22"/>
            </Link>

            <nav className="hidden justify-center lg:flex" aria-label="Main navigation">
              <ul className="glass-nav flex h-11 items-center gap-3 rounded-full px-3 xl:h-14 xl:gap-6 xl:px-5">
                {navLinks.map((link) => {
            const isHome = link.label === "Home";
            return (<li key={link.label}>
                      <Link href={link.href} className={`inline-flex items-center justify-center whitespace-nowrap rounded-full px-3 py-3 text-center font-[family-name:var(--font-lato)] text-[13px] leading-none text-white xl:px-4 xl:text-sm ${isHome ? "gradient-orange font-medium" : "hover:bg-white/10"}`}>
                        {link.label}
                      </Link>
                    </li>);
        })}
              </ul>
            </nav>

            <div className="flex justify-self-end">
              <Link href="/about/get-involved" className="glass-nav hidden h-11 items-center justify-center rounded-full px-5 text-center font-[family-name:var(--font-lato)] text-[13px] leading-none text-white lg:inline-flex xl:h-12 xl:px-6 xl:text-sm">
                Join Now
              </Link>
              <button type="button" className="glass-nav inline-flex h-9 items-center justify-center rounded-full px-4 text-center font-[family-name:var(--font-lato)] text-sm leading-none text-white lg:hidden" aria-expanded={menuOpen} aria-controls="hero-mobile-menu" onClick={() => setMenuOpen((open) => !open)}>
                {menuOpen ? "Close" : "Menu"}
              </button>
            </div>
          </header>

          {menuOpen ? (<div id="hero-mobile-menu" className="absolute inset-x-3 top-[3.6rem] z-30 rounded-2xl border border-white/50 bg-black/55 p-2 shadow-lg backdrop-blur-md sm:inset-x-6 lg:hidden">
              <ul className="flex flex-col">
                {navLinks.map((link) => (<li key={link.label}>
                    <Link href={link.href} className="block rounded-xl px-3 py-2.5 font-[family-name:var(--font-lato)] text-sm text-white hover:bg-white/10" onClick={() => setMenuOpen(false)}>
                      {link.label}
                    </Link>
                  </li>))}
                <li>
                  <Link href="/about/get-involved" className="mt-1 block rounded-full bg-white/10 px-3 py-2.5 text-center font-[family-name:var(--font-lato)] text-sm text-white" onClick={() => setMenuOpen(false)}>
                    Join Now
                  </Link>
                </li>
              </ul>
            </div>) : null}

          <div className="flex flex-1 flex-col items-center justify-end px-2 pb-4 text-center sm:pb-6">
            <h1 className="max-w-[18ch] font-[family-name:var(--font-poppins)] text-[1.65rem] font-semibold leading-[1.2] text-white [text-shadow:0_2px_18px_rgba(0,0,0,0.45)] sm:max-w-[20ch] sm:text-[2.15rem] lg:max-w-[22ch] lg:text-[3.75rem]">
              Support <span className="text-green">Humanity</span>, Spread Kindness Today
            </h1>
            <p className="mt-2 max-w-[34rem] font-[family-name:var(--font-poppins)] text-[0.8rem] leading-snug text-white/95 sm:mt-3 sm:text-base lg:mt-4 lg:text-lg">
              Your small dignity, to those who need it most.
            </p>
            <div className="mt-4 flex flex-wrap items-center justify-center gap-3 sm:mt-5">
              <Link href="/about/donate" className="gradient-orange inline-flex h-11 items-center justify-center rounded-full px-6 text-center font-[family-name:var(--font-lato)] text-sm leading-none text-white sm:h-12 sm:px-7 sm:text-base">
                Donate Now
              </Link>
              <Link href="/about/get-involved" className="inline-flex h-11 items-center justify-center rounded-full border-2 border-white/90 bg-white/10 px-6 text-center font-[family-name:var(--font-lato)] text-sm leading-none text-white backdrop-blur-sm sm:h-12 sm:px-7 sm:text-base">
                Join Now
              </Link>
            </div>

            <div className="mt-3 flex items-center gap-1.5 sm:mt-5" role="tablist" aria-label="Hero slides">
              {slides.map((slide, index) => (<button key={slide.src} type="button" role="tab" aria-selected={index === active} aria-label={`Show slide ${index + 1}`} onClick={() => showSlide(index)} className={`h-1.5 rounded-full transition-all ${index === active ? "w-5 bg-white" : "w-1.5 bg-white/65 hover:bg-white"}`}/>))}
            </div>
          </div>
        </div>
      </div>
    </section>);
}
