import Image from "@/components/next/Image";
import { Button } from "@/components/ui/Button";
import { Section } from "@/components/ui/Section";

const blogs = [
  { title: "Recent events", featured: true },
  { title: "Field updates", featured: false },
  { title: "Awareness blogs", featured: false },
  { title: "Press mentions", featured: false },
];

export function BlogsSection() {
  return (
    <Section>
      <div className="rounded-3xl bg-[rgba(128,178,48,0.1)] px-5 py-12 sm:px-8">
        <h2 className="section-title text-center">
          Latest News <span className="font-medium text-green">/Blogs</span>
        </h2>
        <p className="section-copy mx-auto mt-4 max-w-2xl text-center">
          We work together to uplift communities through compassion, action,
          sustainability, and long-term social impact. Driven by empathy, we
          support vulnerable communities by inspire hope and dignity.
        </p>

        <div className="mt-8 grid items-stretch gap-5 sm:grid-cols-2 xl:grid-cols-4">
          {blogs.map((blog) => (
            <article key={blog.title} className="flex flex-col rounded-3xl bg-white p-4">
              <div className="relative h-40 overflow-hidden rounded-2xl">
                <Image
                  src="/images/blog.jpg"
                  alt={blog.title}
                  fill
                  className="object-cover"
                />
              </div>
              <h3 className="mt-4 text-center font-[family-name:var(--font-poppins)] text-lg font-medium text-text-body">
                {blog.title}
              </h3>
              <p className="mt-2 flex-1 text-center text-sm leading-6 text-text-muted">
                NGO registration requires documents, identity proofs, address.
              </p>
              <div className="mt-4 flex justify-center">
                {blog.featured ? (
                  <Button size="sm">Read More..</Button>
                ) : (
                  <Button variant="outline-orange" size="sm">
                    Read More..
                  </Button>
                )}
              </div>
            </article>
          ))}
        </div>
      </div>
    </Section>
  );
}
