import Image from "@/components/next/Image";
import { AssetImage } from "@/components/ui/AssetImage";
import { Section } from "@/components/ui/Section";

export function EmpowerSection() {
  return (
    <Section>
      <div className="grid items-end gap-5 lg:grid-cols-[1.2fr_0.8fr] lg:gap-12">
        <h2 className="section-title">
          Together We <span className="font-medium text-green">Empower</span>
          <br />
          Lives <strong>Compassion</strong>
        </h2>
        <p className="section-copy lg:pb-1">
          Our mission is to create meaningful change across education,
          healthcare, and community development initiatives. A trusted
          non-profit organization committed to empowering lives through ethical,
          transparent, community-driven programs.
        </p>
      </div>

      <div className="mt-8 grid gap-5 lg:mt-10 lg:grid-cols-3 lg:items-stretch">
        <figure className="overflow-hidden rounded-2xl border-2 border-green">
          <figcaption className="px-5 py-4">
            <h3 className="text-lg font-semibold text-foreground">
              Hope For Humanity
            </h3>
            <p className="mt-1 text-sm leading-6 text-text-muted">
              Helping People Rise Together For A Better And Brighter Future
            </p>
          </figcaption>
          <div className="relative h-56 sm:h-64 lg:h-full lg:min-h-[280px] px-5">
            <h2>Hope For Humanity</h2>
            <p>Helping People Rise Together For A Better And Brighter Future</p>
            <Image
              src="/images/empower-1.jpg"
              alt="Helping the vulnerable"
              fill
              className="object-cover object-center"
              sizes="(max-width: 1024px) 100vw, 360px"
            />
          </div>
        </figure>

        <div className="flex flex-col justify-center rounded-2xl  bg-green px-6 py-8 text-center text-white sm:px-8">
          <h3 className="font-[family-name:var(--font-poppins)] text-xl font-semibold leading-snug sm:text-2xl">
            NGO Planning Health And Hope
          </h3>
          <p className="mt-4 text-sm leading-6 sm:text-base">
            Supporting Poor Families Through Education, Healthcare, Skills And
            Social Development
          </p>
          <p className="mt-3 text-sm leading-6 sm:text-base">
            Creating Opportunities For Youth To Grow, Learn, Lead And Inspire
            Others
          </p>
          <div className="mt-6 flex justify-center">
            <AssetImage
              src="/images/icons/empower-dots.svg"
              alt=""
              width={180}
              height={4}
              className="h-1 w-40"
            />
          </div>
        </div>

        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-1">
          <div className="relative h-48 overflow-hidden rounded-2xl sm:h-56 lg:h-56">
            <Image
              src="/images/empower-3.jpg"
              alt="Children raising hands"
              fill
              className="object-cover object-center"
              sizes="(max-width: 1024px) 50vw, 360px"
            />
          </div>
          <div className="relative h-48 overflow-hidden rounded-2xl border-2 border-green sm:h-56 lg:h-56">
            <Image
              src="/images/empower-2.jpg"
              alt="Children in classroom"
              fill
              className="object-cover object-center"
              sizes="(max-width: 1024px) 50vw, 360px"
            />
          </div>
        </div>
      </div>
    </Section>
  );
}
