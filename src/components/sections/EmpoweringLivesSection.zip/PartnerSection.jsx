import Image from "@/components/next/Image";
import { AssetImage } from "@/components/ui/AssetImage";
import { Section } from "@/components/ui/Section";

const partners = [
  { name: "Corporate partners", icon: "/images/icons/partner-icon-corporate.png" },
  {
    name: "Government associations",
    icon: "/images/icons/partner-icon-government.png",
  },
  { name: "NGOs", icon: "/images/icons/partner-icon-ngo.png" },
  { name: "Institutions", icon: "/images/icons/partner-icon-institution.png" },
];

export function PartnerSection() {
  return (
    <Section>
      <div className="rounded-3xl bg-[#f6f6f6] p-5 sm:p-8">
        <h2 className="section-title">
          Partner <span className="font-medium text-green">& Support</span>
        </h2>
        <p className="section-copy mt-4 max-w-2xl">
          We work together to uplift communities through compassion, action,
          sustainability, and long-term social impact. Driven by empathy, we
          support vulnerable communities by inspire hope and dignity.
        </p>

        <div className="mt-8 grid items-start gap-5 lg:grid-cols-2">
          <div className="grid gap-3">
            {partners.map((partner) => (
              <div
                key={partner.name}
                className="flex items-center gap-4 rounded-full bg-white px-4 py-3"
              >
                <div className="relative h-12 w-12 shrink-0">
                  <AssetImage
                    src="/images/icons/partner-circle.svg"
                    alt=""
                    width={48}
                    height={48}
                    className="h-full w-full object-contain"
                  />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <AssetImage
                      src={partner.icon}
                      alt=""
                      width={28}
                      height={28}
                      className="h-7 w-7 object-contain"
                    />
                  </div>
                </div>
                <h3 className="font-[family-name:var(--font-poppins)] text-base font-medium text-text-body sm:text-lg">
                  {partner.name}
                </h3>
              </div>
            ))}
          </div>

          <div className="grid gap-5 sm:grid-cols-2">
            <div className="relative h-64 overflow-hidden rounded-tl-[4.5rem] rounded-2xl sm:h-72">
              <Image
                src="/images/partner-left.jpg"
                alt="Community support"
                fill
                className="object-cover"
              />
            </div>
            <div className="relative h-64 overflow-hidden rounded-tl-[4.5rem] rounded-2xl sm:h-72">
              <Image
                src="/images/partner-right.jpg"
                alt="Woman and child smiling"
                fill
                className="object-cover"
              />
            </div>
          </div>
        </div>
      </div>
    </Section>
  );
}
