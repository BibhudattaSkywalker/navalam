import { AssetImage } from "@/components/ui/AssetImage";
import { Button } from "@/components/ui/Button";
import { Section } from "@/components/ui/Section";

const cards = [
  {
    title: "Education for All",
    featured: true,
    icon: "/images/icons/icon-education.svg",
  },
  {
    title: "Education for All",
    featured: false,
    icon: "/images/icons/icon-health-orange.svg",
  },
  {
    title: "Education for All",
    featured: false,
    icon: "/images/icons/icon-donate-orange.svg",
  },
  {
    title: "Education for All",
    featured: false,
    icon: "/images/icons/icon-volunteer-orange.svg",
  },
];

export function ImprovementSection() {
  return (
    <Section>
      <div className="rounded-3xl bg-[rgba(185,184,181,0.08)] px-5 pt-12 sm:px-8 sm:pb-[120px] ">
        <h2 className="section-title text-center z-50">
          <span className="font-medium text-green">Improvement</span> For <br/> Every
          <strong className="z-99"> Child</strong> 
        </h2>

        <div className="mt-4 flex justify-center z-0">
          <AssetImage
            src="/images/icons/improvement-badge.svg"
            alt=""
            width={160}
            height={36}
            className="h-8 w-auto ml-32 mt-[-50px]"
          />
        </div>

        <div className="mt-8 grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
          {cards.map((card, index) => (
            <article
              key={index}
              className="flex flex-col rounded-3xl bg-white p-5 shadow-[0px_4px_18px_rgba(0,0,0,0.08)]"
            >
              <div
                className={`mb-4 flex h-14 w-14 items-center justify-center rounded-xl ${
                  card.featured
                    ? "gradient-orange"
                    : "border border-orange bg-[rgba(247,183,13,0.05)]"
                }`}
              >
                <AssetImage
                  src={card.icon}
                  alt=""
                  width={32}
                  height={32}
                  className="h-8 w-8 object-contain"
                />
              </div>
              <h3 className="font-[family-name:var(--font-poppins)] text-lg font-medium text-text-body">
                {card.title}
              </h3>
              <p className="mt-2 flex-1 text-sm leading-6 text-[rgba(130,130,130,0.85)]">
                Serving Society By Improving Lives Through Kindness, Care,
              </p>
              <div className="mt-5">
                {card.featured ? (
                  <Button size="sm">Read More..</Button>
                ) : (
                  <Button variant="outline-orange" size="sm">
                    Read More..
                  </Button>
                )}
              </div>
            </article>
          ))}
        </div>
      </div>
    </Section>
  );
}
