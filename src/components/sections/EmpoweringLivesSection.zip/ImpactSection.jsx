import { AssetImage } from "@/components/ui/AssetImage";
// import { Section } from "@/components/ui/Section";

const stats = [
  { value: "25+", label: "Education for All Lives Compassion" },
  { value: "25+", label: "Education for All Lives Compassion" },
  { value: "25+", label: "Education for All Lives Compassion" },
  { value: "25+", label: "Education for All Lives Compassion" },
];

export function ImpactSection() {
  return (
    <div className="w-[75%] mx-auto mt-[-120px]">
      <div className="rounded-2xl bg-green px-5 py-8 sm:px-8 sm:py-10">
        <div className="mb-6 text-center">
          <p className="font-[family-name:var(--font-poppins)] text-sm font-light text-white/90">
            Impact
          </p>
          <h2 className="font-[family-name:var(--font-poppins)] text-3xl font-medium text-white sm:text-4xl">
            Our Impact
          </h2>
          <div className="mt-3 flex justify-center">
            <AssetImage
              src="/images/icons/impact-line.svg"
              alt=""
              width={140}
              height={16}
              className="h-4 w-auto"
            />
          </div>
        </div>
        <div className="grid gap-12 sm:grid-cols-2 lg:grid-cols-4">
          {stats.map((stat, i) => (
            <div key={i} className="text-white">
              <p className="font-[family-name:var(--font-poppins)] text-4xl font-semibold leading-none">
                {stat.value}
              </p>
              <p className="mt-3 text-sm leading-6 text-white/95">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
