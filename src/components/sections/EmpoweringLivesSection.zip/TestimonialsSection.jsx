import Image from "@/components/next/Image";
import { useState } from "react";
import { AssetImage } from "@/components/ui/AssetImage";
import { Section } from "@/components/ui/Section";

const testimonials = [
  {
    name: "Hannah Schmitt",
    role: "Lead designer",
    avatar: "/images/testimonial-2.png",
    quote:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cursus nibh mauris, nec turpis orci lectus maecenas. Suspendisse sed magna eget nibh in turpis.",
  },
  {
    name: "Hannah Schmitt",
    role: "Lead designer",
    avatar: "/images/testimonial-1.png",
    quote:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cursus nibh mauris, nec turpis orci lectus maecenas. Suspendisse sed magna eget nibh in turpis.",
  },
  {
    name: "Hannah Schmitt",
    role: "Lead designer",
    avatar: "/images/testimonial-3.png",
    quote:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cursus nibh mauris, nec turpis orci lectus maecenas. Suspendisse sed magna eget nibh in turpis.",
  },
];

export function TestimonialsSection() {
  const [active, setActive] = useState(0);
  const prev = () =>
    setActive((i) => (i - 1 + testimonials.length) % testimonials.length);
  const next = () => setActive((i) => (i + 1) % testimonials.length);
  const current = testimonials[active];

  return (
    <Section>
      <div className="rounded-3xl bg-[rgba(241,132,5,0.05)] px-5 py-10 sm:px-8 sm:py-12">
        <div className="mb-8 flex items-center justify-center gap-4">
          <button
            type="button"
            aria-label="Previous testimonial"
            onClick={prev}
            className="rounded-full p-2 hover:bg-white/70"
          >
            <AssetImage
              src="/images/icons/chevron-left.svg"
              alt=""
              width={28}
              height={28}
              className="h-7 w-7 -rotate-90"
            />
          </button>
          <h2 className="section-title text-center text-[1.5rem] sm:text-[1.75rem]">
            What Our Clients Say About Us
          </h2>
          <button
            type="button"
            aria-label="Next testimonial"
            onClick={next}
            className="rounded-full p-2 hover:bg-white/70"
          >
            <AssetImage
              src="/images/icons/chevron-right.svg"
              alt=""
              width={28}
              height={28}
              className="h-7 w-7 rotate-90"
            />
          </button>
        </div>

        <article className="mx-auto flex max-w-xl flex-col items-center rounded-3xl bg-white px-6 py-8 text-center shadow-[0px_8px_24px_rgba(0,0,0,0.06)]">
          <Image
            src={current.avatar}
            alt={current.name}
            width={72}
            height={72}
            className="h-[72px] w-[72px] rounded-full object-cover"
          />
          <AssetImage
            src="/images/icons/quote-icon.svg"
            alt=""
            width={28}
            height={28}
            className="mt-4 h-7 w-7"
          />
          <p className="mt-3 font-[family-name:var(--font-lato)] text-lg font-bold text-[#525252]">
            {current.name}
          </p>
          <p className="font-[family-name:var(--font-lato)] text-sm text-[#828282]">
            {current.role}
          </p>
          <p className="mt-4 text-sm leading-6 text-[#525252]">{current.quote}</p>
        </article>

        <div className="mt-6 flex justify-center gap-2">
          {testimonials.map((_, i) => (
            <button
              key={i}
              type="button"
              aria-label={`Go to testimonial ${i + 1}`}
              onClick={() => setActive(i)}
              className={`h-2 rounded-full transition-all ${
                i === active ? "w-8 bg-orange" : "w-2 bg-orange/30"
              }`}
            />
          ))}
        </div>
      </div>
    </Section>
  );
}
